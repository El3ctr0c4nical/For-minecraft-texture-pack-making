delete this if u want (btw this is only for 1.8.9 
and also if u want put the assets folder in a new folder 
so u can see the textures) 